@echo off
net session >nul 2>&1
if errorlevel 1 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)
powershell -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
echo.
pause
