#!/bin/bash
# =====================================================================
#  КриптоПро CSP + ЭЦП Browser plug-in + Единый клиент JaCarta + автосертификаты
#  Astra Linux SE 1.7 / 1.8 (x86-64)
#
#  Запуск:  bash crypto.sh          — меню
#           bash crypto.sh --now    — установить всё без вопросов
#
#  Положите рядом, в папку crypto/ (одно и то же для всех ПК):
#    linux-amd64_deb.tgz             — КриптоПро CSP (cryptopro.ru, нужна регистрация)
#    JaCarta: архив с сайта Аладдин (.zip/.tar.gz) ИЛИ сами пакеты
#             jacartauc_*_al_x64.deb и jcpkcs11-2_*_al_x64.deb
#    cades-linux-amd64.tar.gz        — плагин (необязательно: попробую скачать сам)
#    license.txt                     — серийный номер КриптоПро (необязательно)
#    root_certs/                     — корневые/промежуточные сертификаты УЦ (.cer/.crt/.p7b)
#    zps_keys/                       — ключи для ЗПС от КриптоПро/Аладдин (если ЗПС включена)
#
#  Как устроена подпись «только с токеном»:
#    сертификат ставится в хранилище пользователя СО ССЫЛКОЙ на ключ на токене.
#    Сам закрытый ключ остаётся на токене. Вынули токен — подписать нечем.
#    Дополнительно при извлечении токена его сертификаты убираются из хранилища,
#    а при вставке — ставятся снова (для всех пользователей ПК, автоматически).
# =====================================================================

SELF="$(readlink -f "$0")"
HERE="$(dirname "$SELF")"
DIST="$HERE/crypto"
CSP_BIN="/opt/cprocsp/bin/amd64"
CSP_SBIN="/opt/cprocsp/sbin/amd64"
WATCH="/usr/local/bin/token-cert-watch"
UNIT="/etc/systemd/user/token-cert-watch.service"
XDG="/etc/xdg/autostart/token-cert-watch.desktop"
PLUGIN_URL="https://www.cryptopro.ru/products/cades/plugin/get_2_0/cades-linux-amd64.tar.gz"
# USB Vendor ID: 24dc — Аладдин (JaCarta, eToken); 0a89 — Актив (Рутокен)
TOKEN_VENDORS="24dc 0a89"

# --- терминал / права ---
if [ ! -t 0 ] && [ -n "$DISPLAY" ] && [ -z "$CRYPTO_IN_TERM" ]; then
    export CRYPTO_IN_TERM=1
    for t in fly-term x-terminal-emulator xterm; do command -v "$t" >/dev/null 2>&1 && exec "$t" -e bash "$SELF" "$@"; done
fi
if [ "$(id -u)" -ne 0 ]; then
    echo "Нужны права администратора. Введите свой пароль:"
    exec sudo env DISPLAY="$DISPLAY" XAUTHORITY="${XAUTHORITY:-$HOME/.Xauthority}" CRYPTO_IN_TERM=1 bash "$SELF" "$@"
fi

G=$'\e[32m'; Y=$'\e[33m'; R=$'\e[31m'; C=$'\e[36m'; N=$'\e[0m'
ok()   { echo "  ${G}[OK]${N} $*"; }
warn() { echo "  ${Y}[!]${N}  $*"; }
err()  { echo "  ${R}[X]${N}  $*"; }
step() { echo; echo "${C}== $*${N}"; }

if [ -n "$DISPLAY" ] && command -v zenity >/dev/null 2>&1; then UI=zenity
elif command -v whiptail >/dev/null 2>&1; then UI=whiptail; else UI=text; fi
TITLE="КриптоПро и токены"
ui_msg()   { set -- "$(printf '%b' "$1")"; [ -n "$NOASK" ] && { echo "$1"; return; }
             case $UI in zenity) zenity --info --title "$TITLE" --text "$1" --width 480 2>/dev/null ;;
                         whiptail) whiptail --title "$TITLE" --msgbox "$1" 20 78 ;;
                         *) echo; echo "$1"; read -r -p "Enter — продолжить " _ ;; esac; }
ui_yesno() { set -- "$(printf '%b' "$1")"; [ -n "$NOASK" ] && return 0
             case $UI in zenity) zenity --question --title "$TITLE" --text "$1" --width 480 2>/dev/null ;;
                         whiptail) whiptail --title "$TITLE" --yesno "$1" 18 78 ;;
                         *) local a; read -r -p "$1 [д/н] " a; [[ "$a" =~ ^[dDдДyY] ]] ;; esac; }
ui_input() { case $UI in zenity) zenity --entry --title "$TITLE" --text "$(printf '%b' "$1")" --entry-text "$2" --width 520 2>/dev/null ;;
                         whiptail) whiptail --title "$TITLE" --inputbox "$(printf '%b' "$1")" 14 78 "$2" 3>&1 1>&2 2>&3 ;;
                         *) local a; printf '%b\n' "$1"; read -r -p "> " a; echo "$a" ;; esac; }
ui_menu()  { local text; text="$(printf '%b' "$1")"; shift
             case $UI in
               zenity) zenity --list --title "$TITLE" --text "$text" --column "Действие" "$@" --width 600 --height 440 --hide-header 2>/dev/null | head -1 ;;
               whiptail) local a=() i=1 it; for it in "$@"; do a+=("$i" "$it"); i=$((i+1)); done
                         local n; n=$(whiptail --title "$TITLE" --menu "$text" 22 84 10 "${a[@]}" 3>&1 1>&2 2>&3) || return 1
                         local all=("$@"); echo "${all[$((n-1))]}" ;;
               *) echo; echo "$text"; local i=1 it; for it in "$@"; do echo "  $i) $it"; i=$((i+1)); done
                  local n; read -r -p "Номер: " n; local all=("$@")
                  [[ "$n" =~ ^[0-9]+$ ]] && [ "$n" -ge 1 ] && [ "$n" -le $# ] && echo "${all[$((n-1))]}" ;;
             esac; }

WORK="$(mktemp -d /tmp/crypto-setup.XXXX)"
trap 'rm -rf "$WORK"' EXIT

zps_enabled() { grep -qsE '^[[:space:]]*DIGSIG_ELF_MODE[[:space:]]*=[[:space:]]*1' /etc/digsig/digsig_initramfs.conf; }
csp_installed() { [ -x "$CSP_BIN/csptestf" ]; }

# ======================= 0. Проверки =======================
preflight() {
    step "Проверка системы"
    local v; v="$(cat /etc/astra_version 2>/dev/null)"
    ok "Astra Linux: ${v:-не определена}"
    [ "$(dpkg --print-architecture)" = amd64 ] || { err "Нужен x86-64 (amd64)"; return 1; }
    if zps_enabled; then
        warn "Включена ЗПС (замкнутая программная среда)"
        if ls "$DIST"/zps_keys/* >/dev/null 2>&1; then
            mkdir -p /etc/digsig/keys
            cp -v "$DIST"/zps_keys/* /etc/digsig/keys/ | sed 's/^/      /'
            update-initramfs -uk all >/dev/null 2>&1
            ok "Ключи ЗПС установлены (после установки нужна перезагрузка)"
            NEED_REBOOT=1
        else
            err "При включённой ЗПС нужны ключи КриптоПро и Аладдин для Astra."
            warn "Положите их в $DIST/zps_keys/ (они есть в дистрибутивах «для Astra Linux, ЗПС»)"
            ui_yesno "Ключей ЗПС нет — без них КриптоПро и JaCarta не запустятся.\nВсё равно продолжить установку?" || return 1
        fi
    else ok "ЗПС выключена"; fi
}

# ======================= 1. Пакеты Astra =======================
install_os_packages() {
    step "Пакеты Astra для токенов (pcscd, libccid, opensc)"
    apt-get update -qq >/dev/null 2>&1
    DEBIAN_FRONTEND=noninteractive apt-get install -y libccid pcscd libpcsclite1 pcsc-tools opensc libgost-astra \
        >/dev/null 2>&1 || DEBIAN_FRONTEND=noninteractive apt-get install -y libccid pcscd libpcsclite1 opensc >/dev/null 2>&1
    systemctl enable --now pcscd.socket >/dev/null 2>&1 || systemctl enable --now pcscd >/dev/null 2>&1
    ok "pcscd запущен"
}

# ======================= 2. КриптоПро CSP =======================
# Ровно те галочки, что в графическом установщике КриптоПро (install_gui.sh):
#   [x] Криптопровайдер KC1            -> install.sh kc1
#   [ ] Провайдер KC2                  -> НЕ ставим
#   [x] Графический интерфейс           -> cprocsp-rdr-gui-gtk
#   [x] Инструменты КриптоПро (cptools) -> cprocsp-cptools-gtk
#   [x] Поддержка смарт-карт и токенов  -> весь набор считывателей ниже (вкл. JaCarta, Рутокен, PC/SC)
#   [x] Библиотека PKCS #11             -> lsb-cprocsp-pkcs11
#   [x] Браузерный плагин + CAdES       -> cprocsp-pki-cades cprocsp-pki-plugin
CSP_READERS="cprocsp-rdr-pcsc cprocsp-rdr-emv cprocsp-rdr-inpaspot cprocsp-rdr-kst cprocsp-rdr-mskey \
cprocsp-rdr-novacard cprocsp-rdr-edoc cprocsp-rdr-rutoken cprocsp-rdr-jacarta cprocsp-rdr-cloud \
cprocsp-rdr-cpfkc cprocsp-rdr-infocrypt cprocsp-rdr-rosan cprocsp-rdr-cryptoki cprocsp-rdr-rustoken"
CSP_EXTRA="cprocsp-rdr-gui-gtk cprocsp-cptools-gtk $CSP_READERS lsb-cprocsp-pkcs11 cprocsp-pki-cades cprocsp-pki-plugin"

csp_version() { dpkg-query -W -f='${Version}' lsb-cprocsp-base 2>/dev/null; }

# КриптоПро уже стоит: доставить только недостающие компоненты из архива (если он есть)
csp_add_missing() {
    local tgz d pk f debs=()
    tgz="$(ls -1 "$DIST"/linux-amd64_deb*.tgz "$HERE"/linux-amd64_deb*.tgz 2>/dev/null | head -1)"
    [ -n "$tgz" ] || { ok "Архива нет — компоненты не доустанавливаю"; return 0; }
    tar -xzf "$tgz" -C "$WORK" 2>/dev/null || return 0
    d="$(find "$WORK" -maxdepth 2 -type f -name install.sh -path '*linux-amd64_deb*' -printf '%h\n' | head -1)"
    [ -n "$d" ] || return 0
    for pk in $CSP_EXTRA; do
        dpkg -s "$pk-64" >/dev/null 2>&1 || dpkg -s "$pk" >/dev/null 2>&1 && continue
        f="$(ls -1 "$d"/"$pk"-64_*.deb "$d"/"$pk"_*.deb 2>/dev/null | head -1)"
        [ -n "$f" ] && debs+=("$f")
    done
    if [ ${#debs[@]} -eq 0 ]; then ok "Все нужные компоненты КриптоПро уже стоят"; return 0; fi
    DEBIAN_FRONTEND=noninteractive apt-get install -y "${debs[@]}" >> "$WORK/csp-install.log" 2>&1 \
        || { dpkg -i "${debs[@]}" >> "$WORK/csp-install.log" 2>&1; DEBIAN_FRONTEND=noninteractive apt-get -f install -y >> "$WORK/csp-install.log" 2>&1; }
    ok "Доустановлено компонентов: ${#debs[@]} ($(printf '%s\n' "${debs[@]}" | xargs -n1 basename | sed 's/_.*//' | tr '\n' ' '))"
}

install_csp() {
    step "КриптоПро CSP"
    if csp_installed; then
        ok "Уже установлен (версия $(csp_version)) — переустанавливать не буду"
        csp_add_missing
        return 0
    fi
    local tgz; tgz="$(ls -1 "$DIST"/linux-amd64_deb*.tgz "$HERE"/linux-amd64_deb*.tgz 2>/dev/null | head -1)"
    if [ -z "$tgz" ]; then
        if csp_installed; then ok "Уже установлен"; return 0; fi
        err "Нет архива КриптоПро CSP (linux-amd64_deb.tgz) в $DIST/"
        warn "Скачайте «КриптоПро CSP 5.0 для Linux (x64, deb)»: https://www.cryptopro.ru/products/csp/downloads"
        return 1
    fi
    tar -xzf "$tgz" -C "$WORK" || { err "Архив повреждён"; return 1; }
    local d; d="$(find "$WORK" -maxdepth 2 -type f -name install.sh -path '*linux-amd64_deb*' -printf '%h\n' | head -1)"
    [ -n "$d" ] || { err "В архиве нет install.sh"; return 1; }
    ok "Архив: $(basename "$tgz"), версия $(sed -n 's/^version=//p' "$d/linux-amd64.ini" 2>/dev/null)"

    # ЗПС: ключ КриптоПро для Astra есть прямо в архиве
    if zps_enabled; then
        local k; k="$(ls -1 "$d"/cprocsp-astra-digsig-key_*.deb 2>/dev/null | head -1)"
        if [ -n "$k" ]; then
            DEBIAN_FRONTEND=noninteractive apt-get install -y "$k" >> "$WORK/csp-install.log" 2>&1 \
                && { ok "Ключ ЗПС КриптоПро установлен"; update-initramfs -uk all >/dev/null 2>&1; NEED_REBOOT=1; } \
                || warn "Ключ ЗПС КриптоПро не установился (см. журнал)"
        fi
    fi

    # ставим только те доп. пакеты, что есть в архиве
    local pk list=""
    for pk in $CSP_EXTRA; do ls "$d"/"$pk"-64_*.deb "$d"/"$pk"_*.deb >/dev/null 2>&1 && list="$list $pk"; done
    ( cd "$d" && ./install.sh --yes kc1 $list ) >> "$WORK/csp-install.log" 2>&1
    if ! csp_installed; then
        err "КриптоПро не установился. Последние строки журнала:"; tail -15 "$WORK/csp-install.log" | sed 's/^/      /'
        return 1
    fi
    ok "КриптоПро CSP: KC1 (без KC2) + поддержка смарт-карт и токенов + PKCS#11 + графика"
    ok "КриптоПро ЭЦП Browser plug-in (из этого же архива)"
    DEBIAN_FRONTEND=noninteractive apt-get -f install -y >> "$WORK/csp-install.log" 2>&1
    cp "$WORK/csp-install.log" /var/log/cryptopro-install.log 2>/dev/null
}

# ---- лицензия: из license.txt или окошком ----
license_view() { "$CSP_SBIN"/cpconfig -license -view 2>/dev/null; }
license_set() {  # $1 = ключ
    local key; key="$(echo "$1" | tr -d ' \r\n' | tr 'a-z' 'A-Z')"
    [ -n "$key" ] || return 1
    if "$CSP_SBIN"/cpconfig -license -set "$key" >/dev/null 2>&1; then
        ok "Лицензия КриптоПро введена"
        license_view | head -4 | sed 's/^/      /'
        return 0
    fi
    err "КриптоПро не принял ключ: $key"
    return 1
}
license_ask() {
    csp_installed || { err "Сначала нужен КриптоПро CSP"; return 1; }
    step "Лицензия КриптоПро"
    if [ -z "$LIC_MANUAL" ] && [ -s "$DIST/license.txt" ]; then
        license_set "$(head -1 "$DIST/license.txt")" && return 0
    fi
    local cur; cur="$(license_view | head -4)"
    if [ -z "$LIC_MANUAL" ] && ! echo "$cur" | grep -qiE 'trial|пробн|expired|истек|demo'; then
        ok "Лицензия уже введена:"; echo "$cur" | sed 's/^/      /'
        return 0
    fi
    local key tries=0
    while [ $tries -lt 3 ]; do
        key="$(ui_input "Введите серийный номер лицензии КриптоПро CSP\n(вида 5050X-XXXXX-XXXXX-XXXXX-XXXXX).\n\nСейчас:\n$cur\n\nОставьте пустым — будет пробный период 90 дней." "")" || key=""
        [ -z "$key" ] && { warn "Лицензия не введена — работает пробный период"; return 0; }
        if license_set "$key"; then
            if ui_yesno "Ключ принят.\n\nСохранить его на флешке (crypto/license.txt),\nчтобы на других ПК он подставлялся сам?\n\n(Только если ваша лицензия рассчитана на несколько ПК.)"; then
                [ -n "$NOASK" ] || { echo "$key" > "$DIST/license.txt"; ok "Сохранён в crypto/license.txt"; }
            fi
            return 0
        fi
        tries=$((tries+1))
        ui_msg "КриптоПро не принял этот номер. Проверьте и введите ещё раз."
    done
}

# ======================= 3. Плагин КриптоПро ЭЦП Browser plug-in =======================
install_plugin() {
    step "КриптоПро ЭЦП Browser plug-in"
    if dpkg -s cprocsp-pki-plugin-64 >/dev/null 2>&1 || dpkg -s cprocsp-pki-plugin >/dev/null 2>&1; then ok "Уже установлен"; return 0; fi
    local arc; arc="$(ls -1 "$DIST"/cades*linux*amd64*.tar.gz 2>/dev/null | head -1)"
    if [ -z "$arc" ]; then
        arc="$WORK/cades-linux-amd64.tar.gz"
        if curl -fsSL --max-time 120 -o "$arc" "$PLUGIN_URL" 2>/dev/null || wget -q -T 120 -O "$arc" "$PLUGIN_URL" 2>/dev/null; then
            ok "Скачан с cryptopro.ru"
        else
            warn "Скачать не удалось — положите cades-linux-amd64.tar.gz в $DIST/ (https://www.cryptopro.ru/products/cades/plugin)"
            return 0
        fi
    fi
    mkdir -p "$WORK/cades" && tar -xzf "$arc" -C "$WORK/cades" 2>/dev/null || { warn "Архив плагина не распаковался"; return 0; }
    local debs=(); while IFS= read -r f; do debs+=("$f"); done < <(find "$WORK/cades" -name 'cprocsp-pki-*amd64*.deb' | grep -vi phpcades | sort)
    [ ${#debs[@]} -gt 0 ] || { warn "В архиве плагина нет пакетов deb"; return 0; }
    dpkg -i "${debs[@]}" >/dev/null 2>&1; DEBIAN_FRONTEND=noninteractive apt-get -f install -y >/dev/null 2>&1
    ok "Плагин установлен (в браузере включите расширение «CryptoPro Extension for CAdES Browser Plug-in»)"
}

# ======================= 4. Единый клиент JaCarta =======================
install_jacarta() {
    step "Единый клиент JaCarta"
    if dpkg -s jacartauc >/dev/null 2>&1 && dpkg -s jcpkcs11-2 >/dev/null 2>&1; then ok "Уже установлен"; return 0; fi
    mkdir -p "$WORK/jc"
    local a
    for a in "$DIST"/*[Jj]a[Cc]arta*.zip "$DIST"/*[Jj]a[Cc]arta*.tar.gz "$DIST"/*[Jj]a[Cc]arta*.tgz "$DIST"/*jacartauc*.zip; do
        [ -f "$a" ] || continue
        case "$a" in *.zip) unzip -qo "$a" -d "$WORK/jc" ;; *) tar -xzf "$a" -C "$WORK/jc" ;; esac && ok "Архив: $(basename "$a")"
    done
    # внутренние архивы (в дистрибутиве Аладдин пакеты могут лежать во вложенном архиве)
    find "$WORK/jc" \( -name '*.tar.gz' -o -name '*.tgz' \) -print0 2>/dev/null | while IFS= read -r -d '' x; do tar -xzf "$x" -C "$(dirname "$x")" 2>/dev/null; done
    pick() {  # лучший пакет: сначала сборка для Astra (_al_), потом общая deb x64
        { find "$DIST" "$WORK/jc" -name "$1*_al_x64.deb" 2>/dev/null; find "$DIST" "$WORK/jc" -name "$1*_x64*.deb" 2>/dev/null; } | head -1
    }
    local lib uc; lib="$(pick jcpkcs11-2_)"; uc="$(pick jacartauc_)"
    if [ -z "$lib" ] || [ -z "$uc" ]; then
        err "Не найдены пакеты Единого клиента JaCarta."
        warn "Скачайте «Единый Клиент JaCarta» для Linux с https://www.aladdin-rd.ru/support/downloads/jacarta_client"
        warn "и положите архив (или jacartauc_*_al_x64.deb + jcpkcs11-2_*_al_x64.deb) в $DIST/"
        return 1
    fi
    dpkg -i "$lib" "$uc" >/dev/null 2>&1
    DEBIAN_FRONTEND=noninteractive apt-get -f install -y >/dev/null 2>&1
    if dpkg -s jcpkcs11-2 >/dev/null 2>&1; then ok "Единая библиотека: $(basename "$lib")"; else err "jcpkcs11-2 не установился"; fi
    if dpkg -s jacartauc >/dev/null 2>&1; then ok "Единый клиент: $(basename "$uc")"; else err "jacartauc не установился"; fi
}

# ======================= 5. Корневые сертификаты УЦ =======================
install_root_certs() {
    [ -d "$DIST/root_certs" ] || return 0
    csp_installed || return 0
    step "Сертификаты удостоверяющих центров (для всех пользователей)"
    local f store n=0
    for f in "$DIST"/root_certs/*; do
        [ -f "$f" ] || continue
        case "${f,,}" in
            *.p7b|*.p7c) "$CSP_BIN"/certmgr -inst -all -store mRoot -file "$f" >/dev/null 2>&1 && n=$((n+1)) ;;
            *.cer|*.crt|*.pem|*.der)
                store=mCA
                if command -v openssl >/dev/null 2>&1; then
                    local s i
                    s="$(openssl x509 -in "$f" -noout -subject 2>/dev/null || openssl x509 -inform der -in "$f" -noout -subject 2>/dev/null)"
                    i="$(openssl x509 -in "$f" -noout -issuer 2>/dev/null || openssl x509 -inform der -in "$f" -noout -issuer 2>/dev/null)"
                    [ -n "$s" ] && [ "${s#subject=}" = "${i#issuer=}" ] && store=mRoot
                fi
                "$CSP_BIN"/certmgr -inst -store "$store" -file "$f" >/dev/null 2>&1 && n=$((n+1)) && ok "$(basename "$f") -> $store" ;;
        esac
    done
    ok "Установлено сертификатов УЦ: $n"
}

# ======================= 6. Автоустановка сертификатов с токена =======================
install_watcher() {
    step "Автоустановка сертификата при вставке токена"
    csp_installed || { err "Сначала нужен КриптоПро CSP"; return 1; }
    cat > "$WATCH" <<EOF
#!/bin/bash
# Следит за токеном: вставили — ставит сертификаты (со ссылкой на ключ на токене),
# вынули — убирает сертификаты этого токена из хранилища пользователя.
CSP="$CSP_BIN"
VENDORS="$TOKEN_VENDORS"
EOF
    cat >> "$WATCH" <<'EOF'
LOCK="${XDG_RUNTIME_DIR:-/tmp}/token-cert-watch-$(id -u).lock"
exec 9>"$LOCK"; flock -n 9 || exit 0          # только один экземпляр на пользователя

present() {
    local v; for v in $VENDORS; do grep -qsx "$v" /sys/bus/usb/devices/*/idVendor && return 0; done; return 1
}
say() {
    command -v notify-send >/dev/null 2>&1 && notify-send -i dialog-password "$1" "$2" 2>/dev/null
    logger -t token-cert "$1: $2"
}
# отпечатки сертификатов в хранилище, ключ которых лежит на токене (не на диске)
token_thumbs() {
    "$CSP"/certmgr -list -store uMy 2>/dev/null | awk '
        /^[0-9]+-+/            { if (t != "" && onToken) print t; t=""; onToken=0 }
        /SHA1 (Hash|Thumbprint)/ { sub(/.*: */, ""); sub(/^0x/, ""); gsub(/ /, ""); t=$0 }
        /^Container/           { c=$0; sub(/.*: */, "", c); if (c !~ /^(HDIMAGE|REGISTRY|\\\\\.\\HDIMAGE|\\\\\.\\REGISTRY)/) onToken=1 }
        END                    { if (t != "" && onToken) print t }'
}
absorb() {
    local i n before after
    before=$(token_thumbs | wc -l)
    for i in 1 2 3 4 5 6; do                # pcscd нужно пару секунд, чтобы увидеть токен
        sleep 2
        "$CSP"/csptestf -absorb -certs -autoprov >/dev/null 2>&1
        after=$(token_thumbs | wc -l)
        [ "$after" -gt 0 ] && break
    done
    if [ "$after" -gt 0 ]; then say "Токен подключён" "Сертификатов: $after. Можно подписывать."
    else say "Токен подключён" "Сертификат на токене не найден"; fi
}
cleanup() {
    local t n=0
    for t in $(token_thumbs); do "$CSP"/certmgr -delete -thumbprint "$t" -store uMy >/dev/null 2>&1 && n=$((n+1)); done
    [ "$n" -gt 0 ] && say "Токен извлечён" "Подписание недоступно, пока токен не вставлен."
}

state=""
while true; do
    if present; then
        [ "$state" != on ] && { absorb; state=on; }
    else
        [ "$state" != off ] && { cleanup; state=off; }
    fi
    sleep 3
done
EOF
    chmod 755 "$WATCH"
    # для всех пользователей: systemd user-сервис + автозапуск сеанса (что сработает — то и запустит; дубли исключены)
    cat > "$UNIT" <<EOF
[Unit]
Description=Автоустановка сертификатов с токена (КриптоПро)
After=graphical-session.target

[Service]
ExecStart=$WATCH
Restart=always
RestartSec=5

[Install]
WantedBy=default.target
EOF
    systemctl --global enable token-cert-watch.service >/dev/null 2>&1
    cat > "$XDG" <<EOF
[Desktop Entry]
Type=Application
Name=Сертификаты с токена
Exec=$WATCH
NoDisplay=true
X-GNOME-Autostart-enabled=true
EOF
    ok "Установлено для всех пользователей этого ПК (заработает со следующего входа в систему)"
    ok "Вставили токен → сертификат ставится сам; вынули → убирается"
    # уже вошедшим пользователям — запустить сразу
    local u uid
    for uid in $(loginctl list-users --no-legend 2>/dev/null | awk '$1>=1000{print $1}'); do
        u="$(id -nu "$uid" 2>/dev/null)"; [ -n "$u" ] || continue
        sudo -u "$u" XDG_RUNTIME_DIR="/run/user/$uid" systemctl --user daemon-reload >/dev/null 2>&1
        sudo -u "$u" XDG_RUNTIME_DIR="/run/user/$uid" systemctl --user restart token-cert-watch.service >/dev/null 2>&1 \
            && ok "Запущено сейчас для пользователя $u"
    done
}
remove_watcher() {
    systemctl --global disable token-cert-watch.service >/dev/null 2>&1
    pkill -f "$WATCH" 2>/dev/null
    rm -f "$UNIT" "$XDG" "$WATCH"
    ok "Автоустановка сертификатов отключена"
}

# ======================= 7. Только токен: запрет ключей на диске =======================
hdimage_present() { "$CSP_SBIN"/cpconfig -hardware reader -view 2>/dev/null | grep -q HDIMAGE; }
token_only_on() {
    csp_installed || { err "Сначала нужен КриптоПро CSP"; return 1; }
    ui_yesno "Запретить хранить ключи на жёстком диске (считыватель HDIMAGE)?\n\nТогда закрытый ключ нельзя скопировать с токена на компьютер —\nподписать можно ТОЛЬКО со вставленным токеном.\n\nВнимание: если у кого-то ключи уже лежат на диске (не на токене),\nони перестанут работать.\n\nВключить?" || return
    "$CSP_SBIN"/cpconfig -hardware reader -del HDIMAGE >/dev/null 2>&1
    hdimage_present && err "Не удалось" || ok "Ключи на диске запрещены — только токен"
}
token_only_off() {
    "$CSP_SBIN"/cpconfig -hardware reader -add HDIMAGE store >/dev/null 2>&1
    hdimage_present && ok "Хранение ключей на диске снова разрешено" || err "Не удалось"
}

# ======================= 8. Проверка =======================
check_now() {
    step "Проверка"
    csp_installed || { err "КриптоПро не установлен"; return; }
    "$CSP_BIN"/csptestf -keyset -verifycontext 2>/dev/null | grep -o 'Ver:[0-9.]*.*' | head -1 | sed 's/^/  КриптоПро: /'
    "$CSP_SBIN"/cpconfig -license -view 2>/dev/null | head -3 | sed 's/^/  /'
    echo "  Считыватели:"; "$CSP_BIN"/csptestf -enum -info -type PP_ENUMREADERS 2>/dev/null | grep -vE '^\s*$|Total|CSP|AcquireContext|OK' | sed 's/^/    /' | head -10
    echo "  Контейнеры на носителях:"; "$CSP_BIN"/csptestf -keyset -enum_cont -fqcn -verifyc 2>/dev/null | grep '\\\\' | sed 's/^/    /'
    hdimage_present && echo "  Ключи на диске: разрешены" || echo "  Ключи на диске: ЗАПРЕЩЕНЫ (только токен)"
    [ -x "$WATCH" ] && echo "  Автоустановка сертификатов: включена" || echo "  Автоустановка сертификатов: выключена"
}

do_all() {
    NEED_REBOOT=""
    preflight || return 1
    install_os_packages
    install_csp || { csp_installed || { err "Без КриптоПро дальше нельзя"; return 1; }; }
    NOASK_SAVE="$NOASK"; NOASK=""; license_ask; NOASK="$NOASK_SAVE"   # окошко лицензии — даже в режиме --now
    install_plugin
    install_jacarta
    install_root_certs
    install_watcher
    if [ -z "$NOASK" ]; then token_only_on; fi
    check_now
    echo; echo "${G}ГОТОВО.${N}"
    local msg="Установлено: КриптоПро CSP, плагин, Единый клиент JaCarta, автоустановка сертификатов.\n\nКак работает:\n • вставили токен — через пару секунд сертификат появляется сам;\n • вынули — сертификат убирается, подписать нельзя.\n\nПользователям нужно выйти и снова войти в систему (или перезагрузить ПК)."
    [ -n "$NEED_REBOOT" ] && msg="$msg\n\nЗПС: ОБЯЗАТЕЛЬНО перезагрузите компьютер."
    ui_msg "$msg"
}

# ======================= МЕНЮ =======================
mkdir -p "$DIST"
if [ "$1" = "--now" ]; then NOASK=1; do_all; exit $?; fi

M1="Установить всё (что уже стоит — пропустит и сделает остальное)"
M2="Только автоустановка сертификатов с токена"
M3="Подписывать только с токеном: запретить ключи на диске"
M4="Разрешить ключи на диске (отменить запрет)"
M5="Проверить: что установлено, какие токены видны"
M8="Ввести / сменить лицензию КриптоПро"
M6="Отключить автоустановку сертификатов"
M7="Выход"
ch="$(ui_menu "Папка с дистрибутивами: $DIST\n\nЧто сделать?" "$M1" "$M8" "$M2" "$M3" "$M4" "$M5" "$M6" "$M7")" || ch="$M7"
case "$ch" in
    "$M1") do_all ;;
    "$M2") install_watcher ;;
    "$M3") token_only_on ;;
    "$M4") token_only_off ;;
    "$M5") check_now ;;
    "$M8") LIC_MANUAL=1; license_ask ;;
    "$M6") remove_watcher ;;
    *) echo "Выход." ;;
esac
[ -n "$CRYPTO_IN_TERM" ] && read -r -p "Enter — закрыть окно " _
