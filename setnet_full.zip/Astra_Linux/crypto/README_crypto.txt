Положите в эту папку (один раз, подходит для всех ПК):

1. linux-amd64_deb.tgz   <- УЖЕ ЛЕЖИТ (КриптоПро CSP 5.0.13820)
   КриптоПро CSP 5.0 для Linux (x64, deb)
   https://www.cryptopro.ru/products/csp/downloads  (нужна бесплатная регистрация)
   Если на ПК включена ЗПС — берите версию «для Astra Linux, ЗПС».

2. Единый Клиент JaCarta для Linux — архив как скачали с сайта
   https://www.aladdin-rd.ru/support/downloads/jacarta_client
   (или сами пакеты jacartauc_*_al_x64.deb и jcpkcs11-2_*_al_x64.deb)

3. (необязательно) cades-linux-amd64.tar.gz — плагин КриптоПро.
   Если его нет, программа попробует скачать сам.

4. (необязательно) license.txt — серийный номер лицензии КриптоПро одной строкой.

5. (необязательно) root_certs/ — сертификаты вашего УЦ (.cer/.crt/.p7b).

6. (только при ЗПС) zps_keys/ — ключи ЗПС от КриптоПро и Аладдин.
