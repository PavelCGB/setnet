#!/bin/bash
# =====================================================================
#  Защищённая сеть + локальная сеть на одном адаптере — Astra Linux
#  (CE / SE, 1.6 / 1.7 / 1.8; нужен NetworkManager)
#
#  Запуск с флешки:  bash astra.sh   (под админом; или двойной щелчок)
#
#  НАСТРОИТЬ:
#   1. Бэкап локальной сети этого ПК -> backups/<имя ПК>-linux.txt
#   2. DHCP + DNS 10.41.129.130/131 -> узнаём IP, маску, шлюз защищённой сети.
#   3. Локальная сеть + второй IP защищённой сети + маршрут 10.0.0.0/8
#      + DNS (сначала рабочие). Подключение — для всех пользователей ПК.
#   4. По желанию — расширение Website Blocker в Chromium-GOST.
#  ВЕРНУТЬ НАЗАД: ровно как было до первого «Настроить» (снимок backups/<ПК>-linux-original.txt).
# =====================================================================

# ============ НАСТРОЙКИ ============
WORK_DNS=(10.41.129.130 10.41.129.131)
# Остальные DNS — идут сразу после рабочих, в этом порядке (как в ручной настройке)
EXTRA_DNS=(10.3.220.1 10.3.220.2 94.230.128.3 94.230.129.3 77.88.8.8 1.1.1.1 8.8.8.8)
ROUTE_NET="10.0.0.0/8"
DEF_WORK_GW="10.5.201.254"          # если DHCP не выдал шлюз
DHCP_WAIT=60
DEF_LOCAL_ADDR="192.168.2.115/22"   # предлагается, если локальная сеть не найдена
DEF_LOCAL_GW="192.168.0.11"
DEF_LOCAL_DNS="1.1.1.1,8.8.8.8"

EXT_ID="gfkapedfefbkecmgmngbciiaafpedpbh"     # Website Blocker
EXT_NAME="Website Blocker"
EXT_URL="https://clients2.google.com/service/update2/crx"
EXT_FILE="website-blocker.json"
# ===================================

SELF="$(readlink -f "$0")"
HERE="$(dirname "$SELF")"

# --- запуск двойным щелчком: открыть терминал ---
if [ ! -t 0 ] && [ -n "$DISPLAY" ] && [ -z "$ASTRA_NET_IN_TERM" ]; then
    export ASTRA_NET_IN_TERM=1
    for t in fly-term x-terminal-emulator xterm; do
        if command -v "$t" >/dev/null 2>&1; then exec "$t" -e bash "$SELF" "$@"; fi
    done
fi

# --- права администратора ---
if [ "$(id -u)" -ne 0 ]; then
    echo "Нужны права администратора. Введите свой пароль:"
    exec sudo env DISPLAY="$DISPLAY" XAUTHORITY="${XAUTHORITY:-$HOME/.Xauthority}" \
        ASTRA_NET_IN_TERM=1 bash "$SELF" "$@"
fi

BACKUP_DIR="$HERE/backups"
PCNAME="$(hostname -s 2>/dev/null || hostname)"
BACKUP="$BACKUP_DIR/${PCNAME}-linux.txt"                 # локальная сеть (для работы программы)
ORIG="$BACKUP_DIR/${PCNAME}-linux-original.txt"          # снимок «как было до программы»
ORIG_HOSTS="$BACKUP_DIR/${PCNAME}-linux-hosts.txt"       # копия /etc/hosts до программы
HOSTS="/etc/hosts"
HB='# >>> WORK-SITES (setup.ps1) >>>'
HE='# <<< WORK-SITES (setup.ps1) <<<'

G=$'\e[32m'; Y=$'\e[33m'; R=$'\e[31m'; C=$'\e[36m'; N=$'\e[0m'
ok()   { echo "  ${G}[OK]${N} $*"; }
warn() { echo "  ${Y}[!]${N}  $*"; }
step() { echo; echo "${C}== $*${N}"; }

# ======================= ОКНА (zenity / whiptail / текст) =======================
if [ -n "$DISPLAY" ] && command -v zenity >/dev/null 2>&1; then UI=zenity
elif command -v whiptail >/dev/null 2>&1; then UI=whiptail
else UI=text; fi
TITLE="Защищённая сеть"

ui_msg() {
    set -- "$(printf '%b' "$1")"
    case $UI in
        zenity)   zenity --info --title "$TITLE" --text "$1" --width 420 2>/dev/null ;;
        whiptail) whiptail --title "$TITLE" --msgbox "$1" 16 72 ;;
        *)        echo; echo "$1"; read -r -p "Enter — продолжить " _ ;;
    esac
}
ui_yesno() {
    set -- "$(printf '%b' "$1")"
    case $UI in
        zenity)   zenity --question --title "$TITLE" --text "$1" --width 420 2>/dev/null ;;
        whiptail) whiptail --title "$TITLE" --yesno "$1" 14 72 ;;
        *)        local a; read -r -p "$1 [д/н] " a; [[ "$a" =~ ^[dDдДyY] ]] ;;
    esac
}
ui_input() {
    case $UI in
        zenity)   zenity --entry --title "$TITLE" --text "$1" --entry-text "$2" --width 420 2>/dev/null ;;
        whiptail) whiptail --title "$TITLE" --inputbox "$1" 10 72 "$2" 3>&1 1>&2 2>&3 ;;
        *)        local a; read -r -p "$1 [$2]: " a; echo "${a:-$2}" ;;
    esac
}
ui_menu() {  # текст, пункты... -> выбранный пункт
    local text="$1"; shift
    case $UI in
        zenity)
            zenity --list --title "$TITLE" --text "$text" --column "Действие" "$@" \
                --width 480 --height 340 --hide-header 2>/dev/null | head -1 ;;
        whiptail)
            local args=() i=1 it
            for it in "$@"; do args+=("$i" "$it"); i=$((i+1)); done
            local n; n=$(whiptail --title "$TITLE" --menu "$text" 18 76 8 "${args[@]}" 3>&1 1>&2 2>&3) || return 1
            local all=("$@"); echo "${all[$((n-1))]}" ;;
        *)
            echo >&2; echo "$text" >&2; local i=1 it
            for it in "$@"; do echo "  $i) $it" >&2; i=$((i+1)); done
            local n; read -r -p "Номер: " n
            local all=("$@"); [[ "$n" =~ ^[0-9]+$ ]] && [ "$n" -ge 1 ] && [ "$n" -le $# ] && echo "${all[$((n-1))]}" ;;
    esac
}

# ======================= ВСПОМОГАТЕЛЬНОЕ =======================
is_v4()  { [[ "$1" =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}$ ]]; }
ip2int() { local IFS=.; set -- $1; echo $(( ($1<<24) + ($2<<16) + ($3<<8) + $4 )); }
same_net() {  # ip1 ip2 prefix
    local m=$(( (0xFFFFFFFF << (32 - $3)) & 0xFFFFFFFF ))
    [ $(( $(ip2int "$1") & m )) -eq $(( $(ip2int "$2") & m )) ]
}
is_work_dns() { local d; for d in "${WORK_DNS[@]}"; do [ "$1" = "$d" ] && return 0; done; return 1; }
join_by() { local IFS="$1"; shift; echo "$*"; }

conf()      { nmcli -t -f "$2" con show "$1" 2>/dev/null | head -1 | sed "s/^$2://"; }
# Адреса и шлюз устройства: сначала берём из ip (он всегда честно показывает, что
# выдал DHCP), и только если ip ничего не дал — спрашиваем nmcli.
dev_addrs() {
    local a
    a="$(ip -4 -o addr show dev "$1" 2>/dev/null | awk '{print $4}' | grep -E '^[0-9.]+/[0-9]+$')"
    [ -n "$a" ] && { echo "$a"; return 0; }
    nmcli -t -f IP4.ADDRESS dev show "$1" 2>/dev/null | sed 's/^[^:]*://' | grep -E '^[0-9.]+/[0-9]+$'
}
dev_gw() {
    local g
    g="$(ip -4 route show default dev "$1" 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="via"){print $(i+1); exit}}')"
    [ -n "$g" ] && { echo "$g"; return 0; }
    nmcli -t -f IP4.GATEWAY dev show "$1" 2>/dev/null | sed 's/^[^:]*://' | grep -E '^[0-9.]+$' | head -1
}

# Убрать старый блок сайтов из /etc/hosts (от прежних версий программы)
clean_hosts() {
    grep -qxF "$HB" "$HOSTS" 2>/dev/null || return 0
    local tmp; tmp=$(mktemp)
    awk -v b="$HB" -v e="$HE" '$0==b{f=1;next} $0==e{f=0;next} !f' "$HOSTS" \
      | awk '{a[NR]=$0} END{n=NR; while(n>0 && a[n] ~ /^[ \t]*$/) n--; for(i=1;i<=n;i++) print a[i]}' > "$tmp"
    cat "$tmp" > "$HOSTS"; rm -f "$tmp"
    ok "Старые записи сайтов убраны из /etc/hosts"
}

# Текущие настройки подключения без того, что добавляет программа
read_current() {  # -> CUR_METHOD CUR_ADDRS(массив) CUR_GW CUR_DNS CUR_ROUTES CUR_IGN
    local a d r
    CUR_METHOD="$(conf "$CON_UUID" ipv4.method)"
    CUR_GW="$(conf "$CON_UUID" ipv4.gateway)"; [ "$CUR_GW" = "--" ] && CUR_GW=""
    CUR_IGN="$(conf "$CON_UUID" ipv4.ignore-auto-dns)"
    CUR_ADDRS=(); local dns=() routes=()
    IFS=', ' read -r -a _a <<< "$(conf "$CON_UUID" ipv4.addresses)"
    for a in "${_a[@]}"; do [ -n "$a" ] && [[ "$a" != 10.* ]] && CUR_ADDRS+=("$a"); done
    IFS=', ' read -r -a _d <<< "$(conf "$CON_UUID" ipv4.dns)"
    for d in "${_d[@]}"; do [ -n "$d" ] && [[ "$d" != 10.* ]] && ! is_work_dns "$d" && dns+=("$d"); done
    CUR_DNS="$(join_by , "${dns[@]}")"
    CUR_ROUTES="$(san_routes "$(conf "$CON_UUID" ipv4.routes)")"
}

# ---- бэкап ----
save_backup() {  # method addrs gw dns routes ignore_dns
    mkdir -p "$BACKUP_DIR"
    {
        echo "PC=$PCNAME"; echo "METHOD=$1"; echo "ADDRS=$2"; echo "GW=$3"
        echo "DNS=$4"; echo "ROUTES=$5"; echo "IGNORE_DNS=$6"; echo "DATE=$(date '+%F %T')"
    } > "$BACKUP"
}
load_backup() {
    BK_METHOD=""; BK_ADDRS=""; BK_GW=""; BK_DNS=""; BK_ROUTES=""; BK_IGN="no"
    [ -f "$BACKUP" ] || return 1
    local k v
    while IFS='=' read -r k v; do
        v="${v%$'\r'}"
        case "$k" in
            METHOD) BK_METHOD="$v" ;; ADDRS) BK_ADDRS="$v" ;; GW) BK_GW="$v" ;;
            DNS) BK_DNS="$v" ;; ROUTES) BK_ROUTES="$v" ;; IGNORE_DNS) BK_IGN="$v" ;;
        esac
    done < "$BACKUP"
    BK_ADDRS="$(san_addrs "$BK_ADDRS")"; BK_DNS="$(san_dns "$BK_DNS")"; BK_ROUTES="$(san_routes "$BK_ROUTES")"
    [ "$BK_METHOD" = auto ] || [ -n "$BK_ADDRS" ]
}
apply_backup() {  # uuid
    if [ "$BK_METHOD" = auto ]; then
        nmcli con mod "$1" ipv4.method auto ipv4.addresses "" ipv4.gateway "" \
            ipv4.dns "$BK_DNS" ipv4.routes "$BK_ROUTES" ipv4.ignore-auto-dns "${BK_IGN:-no}"
    else
        nmcli con mod "$1" ipv4.method manual ipv4.addresses "$BK_ADDRS" ipv4.gateway "$BK_GW" \
            ipv4.dns "$BK_DNS" ipv4.routes "$BK_ROUTES" ipv4.ignore-auto-dns "${BK_IGN:-no}"
    fi
    nmcli --wait 30 con up "$1" >/dev/null 2>&1
}

# ---- убрать из настроек всё, что относится к защищённой сети ----
san_addrs()  { local a o=(); IFS=', ' read -r -a _x <<< "$1"; for a in "${_x[@]}"; do [ -n "$a" ] && [[ "$a" != 10.* ]] && o+=("$a"); done; join_by , "${o[@]}"; }
san_dns()    { local a o=(); IFS=', ' read -r -a _x <<< "$1"; for a in "${_x[@]}"; do [ -n "$a" ] && [[ "$a" != 10.* ]] && ! is_work_dns "$a" && o+=("$a"); done; join_by , "${o[@]}"; }
san_routes() { local r o=(); IFS=',' read -r -a _x <<< "$1"; for r in "${_x[@]}"; do r="$(echo "$r" | sed 's/^ *//')"; [ -n "$r" ] && [[ "$r" != "$ROUTE_NET"* ]] && [[ "$r" != 10.* ]] && o+=("$r"); done; join_by , "${o[@]}"; }

# ---- снимок «как было до запуска программы» (делается один раз) ----
save_original() {  # uuid
    if [ -f "$ORIG" ]; then
        ok "Снимок исходных настроек уже есть ($(grep '^DATE=' "$ORIG" | cut -d= -f2-)) — не трогаю"
        return 0
    fi
    mkdir -p "$BACKUP_DIR"
    local g; g="$(conf "$1" ipv4.gateway)"; [ "$g" = "--" ] && g=""
    {
        echo "PC=$PCNAME"
        echo "UUID=$1"
        echo "METHOD=$(conf "$1" ipv4.method)"
        echo "ADDRS=$(san_addrs "$(conf "$1" ipv4.addresses)")"
        echo "GW=$g"
        echo "DNS=$(san_dns "$(conf "$1" ipv4.dns)")"
        echo "ROUTES=$(san_routes "$(conf "$1" ipv4.routes)")"
        echo "IGNORE_DNS=$(conf "$1" ipv4.ignore-auto-dns)"
        echo "PERM=$(conf "$1" connection.permissions)"
        echo "DATE=$(date '+%F %T')"
    } > "$ORIG"
    cp "$HOSTS" "$ORIG_HOSTS"
    ok "Снимок исходных настроек сохранён: backups/${PCNAME}-linux-original.txt"
}
load_original() {
    O_UUID=""; O_METHOD=""; O_ADDRS=""; O_GW=""; O_DNS=""; O_ROUTES=""; O_IGN="no"; O_PERM=""; O_DATE=""
    [ -f "$ORIG" ] || return 1
    local k v
    while IFS='=' read -r k v; do
        v="${v%$'\r'}"; [ "$v" = "--" ] && v=""
        case "$k" in
            UUID) O_UUID="$v" ;; METHOD) O_METHOD="$v" ;; ADDRS) O_ADDRS="$v" ;; GW) O_GW="$v" ;;
            DNS) O_DNS="$v" ;; ROUTES) O_ROUTES="$v" ;; IGNORE_DNS) O_IGN="$v" ;; PERM) O_PERM="$v" ;; DATE) O_DATE="$v" ;;
        esac
    done < "$ORIG"
    O_ADDRS="$(san_addrs "$O_ADDRS")"; O_DNS="$(san_dns "$O_DNS")"; O_ROUTES="$(san_routes "$O_ROUTES")"
    [[ "$O_GW" == 10.* ]] && O_GW=""
    if [ "$O_METHOD" = manual ] && [ -z "$O_ADDRS" ]; then O_METHOD=auto; O_GW=""; fi
    [ "$O_METHOD" = manual ] || O_IGN="no"
    [ -n "$O_METHOD" ]
}
apply_original() {  # uuid (по умолчанию — то же подключение, что было в снимке)
    local u="$1"
    [ -n "$O_UUID" ] && nmcli -t -f UUID con show "$O_UUID" >/dev/null 2>&1 && u="$O_UUID"
    nmcli con mod "$u" ipv4.addresses "$O_ADDRS" ipv4.gateway "$O_GW" ipv4.method "$O_METHOD" \
        ipv4.dns "$O_DNS" ipv4.routes "$O_ROUTES" ipv4.ignore-auto-dns "${O_IGN:-no}" \
        connection.permissions "$O_PERM" || return 1
    nmcli --wait 30 con up "$u" >/dev/null 2>&1
    return 0
}

# ---- выбор проводного подключения ----
pick_conn() {
    command -v nmcli >/dev/null 2>&1 || { echo "${R}Не найден NetworkManager (nmcli). Программа работает только с ним.${N}"; return 1; }
    local lines=() l uuid type dev name
    while IFS= read -r l; do
        IFS=: read -r uuid type dev name <<< "$l"
        [[ "$type" == *ethernet* ]] && [ -n "$dev" ] && lines+=("$uuid|$dev|$name")
    done < <(nmcli -t -f UUID,TYPE,DEVICE,NAME con show --active 2>/dev/null)
    if [ ${#lines[@]} -eq 0 ]; then echo "${R}Нет активного проводного подключения. Проверьте кабель.${N}"; return 1; fi
    local pick="${lines[0]}"
    if [ ${#lines[@]} -gt 1 ]; then
        local items=() x i ch
        for x in "${lines[@]}"; do items+=("$(echo "$x" | cut -d'|' -f3) ($(echo "$x" | cut -d'|' -f2))"); done
        ch=$(ui_menu "Какое подключение настраивать (куда воткнут кабель)?" "${items[@]}") || return 1
        for i in "${!items[@]}"; do [ "${items[$i]}" = "$ch" ] && pick="${lines[$i]}"; done
    fi
    CON_UUID="${pick%%|*}"; local rest="${pick#*|}"; CON_DEV="${rest%%|*}"; CON_NAME="${rest#*|}"
    ok "Подключение: $CON_NAME ($CON_DEV)"
}

# ======================= РАСШИРЕНИЕ БРАУЗЕРА (только Chromium-GOST) =======================
# Chromium-GOST читает политики из /etc/chromium/policies (как обычный Chromium).
POLICY_DIR="/etc/chromium/policies/managed"

gost_dir() {  # папка установки Chromium-GOST
    local b d
    for d in /opt/chromium-gost /opt/chromium-gost-stable; do [ -d "$d" ] && { echo "$d"; return 0; }; done
    for b in chromium-gost chromium-gost-stable; do
        if command -v "$b" >/dev/null 2>&1; then
            b="$(readlink -f "$(command -v "$b")")"
            # если это скрипт-обёртка — ищем в нём путь /opt/...
            d="$(grep -aoE '/opt/[A-Za-z0-9._-]+' "$b" 2>/dev/null | head -1)"
            [ -n "$d" ] && [ -d "$d" ] && { echo "$d"; return 0; }
            echo "$(dirname "$b")"; return 0
        fi
    done
    return 1
}
plain_chromium() {  # установлен ли обычный Chromium
    [ -x /usr/lib/chromium/chromium ] || [ -x /usr/lib/chromium-browser/chromium-browser ] || \
    dpkg -s chromium >/dev/null 2>&1 || dpkg -s chromium-browser >/dev/null 2>&1
}
ext_policy() {
    mkdir -p "$POLICY_DIR"
    printf '{\n  "ExtensionInstallForcelist": [\n    "%s;%s"\n  ]\n}\n' "$EXT_ID" "$EXT_URL" > "$POLICY_DIR/$EXT_FILE"
    chmod 644 "$POLICY_DIR/$EXT_FILE"
    ok "Политика: $POLICY_DIR/$EXT_FILE"
}
ext_gost_folder() {  # только для Chromium-GOST, через папку extensions браузера
    local d="$1/extensions"
    mkdir -p "$d"
    printf '{\n  "external_update_url": "%s"\n}\n' "$EXT_URL" > "$d/$EXT_ID.json"
    chmod 644 "$d/$EXT_ID.json"
    ok "Папка Chromium-GOST: $d/$EXT_ID.json"
}
ext_install() {
    step "Ставлю расширение $EXT_NAME в Chromium-GOST"
    local gd; gd="$(gost_dir)"
    if [ -z "$gd" ]; then
        warn "Chromium-GOST не найден на этом компьютере"
        ui_msg "Chromium-GOST не найден — расширение не поставлено."
        return 1
    fi
    ok "Chromium-GOST: $gd"
    local how="policy"
    if plain_chromium; then
        local P="Обязательно для всех (попадёт и в обычный Chromium, удалить нельзя)"
        local F="Только в Chromium-GOST (при первом запуске нажать «Включить»)"
        local ch; ch="$(ui_menu "На компьютере есть и обычный Chromium. Как ставить расширение?" "$F" "$P")" || { echo "Отменено."; return; }
        case "$ch" in "$P") how="policy" ;; "$F") how="folder" ;; *) echo "Отменено."; return ;; esac
    fi
    if [ "$how" = policy ]; then
        rm -f "$gd/extensions/$EXT_ID.json"
        ext_policy
        ui_msg "Расширение $EXT_NAME будет установлено в Chromium-GOST у всех пользователей.\n\nЗакройте и откройте Chromium-GOST — оно появится само (нужен интернет).\nСписок блокируемых сайтов настраивается в самом расширении."
    else
        rm -f "$POLICY_DIR/$EXT_FILE"
        ext_gost_folder "$gd"
        ui_msg "Расширение $EXT_NAME будет добавлено только в Chromium-GOST.\n\nПри следующем запуске Chromium-GOST появится сообщение о новом расширении — нажмите «Включить» (нужен интернет)."
    fi
    ok "Готово. Перезапустите Chromium-GOST."
}
ext_remove() {
    step "Убираю расширение $EXT_NAME"
    local f n=0 gd
    for f in /etc/chromium/policies/managed /etc/chromium-browser/policies/managed /etc/opt/chrome/policies/managed \
             /etc/opt/yandex/browser/policies/managed /etc/chromium-gost/policies/managed /etc/opt/chromium-gost/policies/managed; do
        if [ -f "$f/$EXT_FILE" ]; then rm -f "$f/$EXT_FILE"; ok "Удалено: $f/$EXT_FILE"; n=$((n+1)); fi
    done
    gd="$(gost_dir)"
    if [ -n "$gd" ] && [ -f "$gd/extensions/$EXT_ID.json" ]; then rm -f "$gd/extensions/$EXT_ID.json"; ok "Удалено: $gd/extensions/$EXT_ID.json"; n=$((n+1)); fi
    [ $n -eq 0 ] && warn "Расширение не было поставлено этой программой"
    ui_msg "Готово. После перезапуска браузера расширение исчезнет.\n(Если ставилось «только в Chromium-GOST», его можно удалить и вручную в самом браузере.)"
}

# ======================= ВЕРНУТЬ НАЗАД =======================
do_revert() {
    ui_yesno "Убрать защищённую сеть и вернуть настройки как были до программы?\n\n(второй адрес 10.x, маршрут 10.0.0.0 и рабочие DNS будут убраны)" || { echo "Отменено."; return; }
    step "Ищу проводное подключение"; pick_conn || return 1
    if load_original; then
        step "Возвращаю всё как было до программы (снимок от $O_DATE)"
        apply_original "$CON_UUID" || { echo "${R}nmcli не смог применить снимок${N}"; ui_msg "Ошибка: не удалось применить снимок."; return 1; }
        ok "Метод: $O_METHOD"
        ok "Адреса: ${O_ADDRS:-авто}"
        ok "Шлюз: ${O_GW:-авто}"
        ok "DNS: ${O_DNS:-авто}"
        ok "Маршруты: ${O_ROUTES:-нет}"
        if [ -f "$ORIG_HOSTS" ]; then cat "$ORIG_HOSTS" > "$HOSTS"; ok "/etc/hosts — как было"; fi
        rm -f "$ORIG" "$ORIG_HOSTS"
        ok "Снимок использован и удалён (при следующей настройке сделается новый)"
        sleep 3
        step "Проверка"
        if ping -c 2 -W 2 1.1.1.1 >/dev/null 2>&1; then ok "Интернет отвечает"; else warn "Интернет пока не отвечает — подождите минуту"; fi
        echo; echo "${G}ВСЁ ВОЗВРАЩЕНО КАК БЫЛО.${N}"
        ui_msg "Всё возвращено как было до запуска программы.\n\nЕсли было открыто окно настроек подключения — закройте и откройте его заново."
        return
    fi
    step "Возвращаю локальную сеть"
    warn "Снимка «как было» нет — беру бэкап локальной сети"
    if load_backup; then
        ok "Бэкап этого ПК: backups/${PCNAME}-linux.txt"
    else
        warn "Бэкапа нет — убираю только то, что добавила программа"
        read_current
        BK_METHOD="$CUR_METHOD"; BK_ADDRS="$(join_by , "${CUR_ADDRS[@]}")"; BK_GW="$CUR_GW"
        BK_DNS="$CUR_DNS"; BK_ROUTES="$CUR_ROUTES"; BK_IGN="no"
        if [ "$BK_METHOD" = manual ] && [ -z "$BK_ADDRS" ]; then BK_METHOD=auto; fi
    fi
    apply_backup "$CON_UUID"
    ok "Сеть: ${BK_METHOD} ${BK_ADDRS} шлюз ${BK_GW:-авто}"
    clean_hosts
    sleep 3
    step "Проверка"
    if ping -c 2 -W 2 1.1.1.1 >/dev/null 2>&1; then ok "Интернет отвечает"; else warn "Интернет пока не отвечает — подождите минуту"; fi
    echo; echo "${G}ВСЁ ВОЗВРАЩЕНО.${N}"
    ui_msg "Всё возвращено."
}

# ======================= НАСТРОИТЬ =======================
APPLIED=0; DHCP_STARTED=0
on_fail() {
    echo; echo "${R}ОШИБКА: $*${N}"
    if [ "$DHCP_STARTED" = 1 ] && [ "$APPLIED" = 0 ] && [ -n "$CON_UUID" ]; then
        echo "  ${Y}Возвращаю сеть как было...${N}"
        if load_original; then apply_original "$CON_UUID" && ok "Сеть восстановлена как было"
        elif load_backup; then apply_backup "$CON_UUID" && ok "Локальная сеть восстановлена"
        else warn "Бэкапа нет — нажмите «Вернуть назад» или настройте сеть вручную"; fi
    fi
    ui_msg "Ошибка: $*"
    exit 1
}

do_setup() {
    step "Ищу проводное подключение"; pick_conn || exit 1
    save_original "$CON_UUID"

    # --- локальная сеть ---
    step "Проверяю текущую сеть"
    echo "  Компьютер: $PCNAME"
    read_current
    local how
    LOCAL_ADDR=""; LOCAL_GW=""; LOCAL_DNS="$CUR_DNS"
    if [ "$CUR_METHOD" = manual ] && [ ${#CUR_ADDRS[@]} -gt 0 ] && [ -n "$CUR_GW" ] && [[ "$CUR_GW" != 10.* ]]; then
        LOCAL_ADDR="${CUR_ADDRS[0]}"; LOCAL_GW="$CUR_GW"
        ok "Локальная сеть: $LOCAL_ADDR, шлюз $LOCAL_GW"
        [ -f "$BACKUP" ] && how="обновлён" || how="создан"
        save_backup manual "$(join_by , "${CUR_ADDRS[@]}")" "$CUR_GW" "$CUR_DNS" "$CUR_ROUTES" "${CUR_IGN:-no}"
        ok "Бэкап $how: backups/${PCNAME}-linux.txt"
    else
        local cur cgw
        cur="$(dev_addrs "$CON_DEV" | grep -v '^10\.' | grep -v '^169\.254\.' | head -1)"
        cgw="$(dev_gw "$CON_DEV")"
        if [ "$CUR_METHOD" = auto ] && ! { [ "$CUR_IGN" = yes ] && [ -z "$CUR_DNS" ]; }; then
            [ -f "$BACKUP" ] && how="обновлён" || how="создан"
            save_backup auto "" "" "$CUR_DNS" "$CUR_ROUTES" "${CUR_IGN:-no}"
            ok "Бэкап $how (сеть была автоматической): backups/${PCNAME}-linux.txt"
        fi
        if [ -n "$cur" ] && [ -n "$cgw" ] && [[ "$cgw" != 10.* ]]; then
            LOCAL_ADDR="$cur"; LOCAL_GW="$cgw"
            ok "Локальная сеть (сейчас): $LOCAL_ADDR, шлюз $LOCAL_GW"
        elif load_backup && [ "$BK_METHOD" = manual ]; then
            LOCAL_ADDR="${BK_ADDRS%%,*}"; LOCAL_GW="$BK_GW"; [ -z "$LOCAL_DNS" ] && LOCAL_DNS="$BK_DNS"
            warn "Беру локальную сеть из бэкапа: $LOCAL_ADDR, шлюз $LOCAL_GW"
        else
            warn "Локальная сеть не найдена — спрашиваю"
            LOCAL_ADDR="$(ui_input "IP локальной сети этого ПК с маской (например 192.168.2.115/22):" "$DEF_LOCAL_ADDR")" || { echo "Отменено."; return; }
            LOCAL_GW="$(ui_input "Шлюз локальной сети:" "$DEF_LOCAL_GW")" || { echo "Отменено."; return; }
            [[ "$LOCAL_ADDR" == */* ]] || LOCAL_ADDR="$LOCAL_ADDR/24"
        fi
    fi
    [ -z "$LOCAL_DNS" ] && LOCAL_DNS="$DEF_LOCAL_DNS"
    { is_v4 "${LOCAL_ADDR%/*}" && is_v4 "$LOCAL_GW"; } || on_fail "Неверные данные локальной сети: $LOCAL_ADDR / $LOCAL_GW"

    # --- DHCP защищённой сети ---
    step "Получаю настройки защищённой сети по DHCP"
    DHCP_STARTED=1
    nmcli con mod "$CON_UUID" ipv4.method auto ipv4.addresses "" ipv4.gateway "" ipv4.routes "" \
        ipv4.dns "$(join_by , "${WORK_DNS[@]}")" ipv4.ignore-auto-dns yes || on_fail "nmcli не смог включить DHCP"
    nmcli --wait "$DHCP_WAIT" con up "$CON_UUID" >/dev/null 2>&1
    WORK_ADDR=""; WORK_GW=""
    local t=0 x ip pfx g
    while [ $t -lt $DHCP_WAIT ]; do
        for x in $(dev_addrs "$CON_DEV"); do
            ip="${x%/*}"; pfx="${x#*/}"
            [[ "$ip" == 169.254.* ]] && continue
            [ "$ip" = "${LOCAL_ADDR%/*}" ] && continue
            WORK_ADDR="$x"
            g="$(dev_gw "$CON_DEV")"
            if [ -n "$g" ] && same_net "$g" "$ip" "$pfx"; then WORK_GW="$g"; fi
            break
        done
        [ -n "$WORK_ADDR" ] && [ -n "$WORK_GW" ] && break
        echo "  ...жду ответ DHCP"; sleep 3; t=$((t+3))
    done
    [ -n "$WORK_ADDR" ] || on_fail "Защищённая сеть не выдала адрес за $DHCP_WAIT сек."
    if [ -z "$WORK_GW" ]; then
        if same_net "$DEF_WORK_GW" "${WORK_ADDR%/*}" "${WORK_ADDR#*/}"; then
            WORK_GW="$DEF_WORK_GW"; warn "DHCP не выдал шлюз — беру из настроек: $DEF_WORK_GW"
        else on_fail "Не удалось определить шлюз защищённой сети (адрес $WORK_ADDR)"; fi
    fi
    ok "Защищённая сеть: $WORK_ADDR, шлюз $WORK_GW"

    # --- локальная + защищённая ---
    step "Возвращаю локальную сеть и добавляю защищённую"
    local alldns d; alldns="$(join_by , "${WORK_DNS[@]}" "${EXTRA_DNS[@]}")"
    IFS=',' read -r -a _ld <<< "$LOCAL_DNS"
    for d in "${_ld[@]}"; do d="${d// /}"; [ -n "$d" ] && [[ ",$alldns," != *",$d,"* ]] && alldns="$alldns,$d"; done
    local allroutes="$ROUTE_NET $WORK_GW"; [ -n "$CUR_ROUTES" ] && allroutes="$allroutes,$CUR_ROUTES"
    nmcli con mod "$CON_UUID" ipv4.method manual ipv4.addresses "$LOCAL_ADDR,$WORK_ADDR" \
        ipv4.gateway "$LOCAL_GW" ipv4.dns "$alldns" ipv4.ignore-auto-dns yes ipv4.routes "$allroutes" \
        connection.permissions "" connection.autoconnect yes \
        || on_fail "nmcli не смог применить настройки"
    nmcli --wait 30 con up "$CON_UUID" >/dev/null 2>&1
    APPLIED=1
    ok "IP: $LOCAL_ADDR и $WORK_ADDR"
    ok "Шлюз (интернет): $LOCAL_GW"
    ok "Маршрут: $ROUTE_NET -> $WORK_GW"
    ok "DNS: $alldns"
    ok "Подключение доступно всем пользователям этого компьютера"
    clean_hosts
    sleep 4

    step "Проверка"
    if ping -c 2 -W 2 1.1.1.1 >/dev/null 2>&1; then ok "Интернет (1.1.1.1) — отвечает"; else warn "Интернет (1.1.1.1) — НЕ отвечает"; fi
    if ping -c 2 -W 2 "${WORK_DNS[0]}" >/dev/null 2>&1; then ok "Защищённая сеть (${WORK_DNS[0]}) — отвечает"; else warn "Защищённая сеть (${WORK_DNS[0]}) — НЕ отвечает"; fi
    echo; echo "${G}СЕТЬ НАСТРОЕНА.${N}"

    if gost_dir >/dev/null && ui_yesno "Сеть настроена.\nЗащищённая сеть: $WORK_ADDR\n\nПоставить в Chromium-GOST расширение $EXT_NAME\n(блокировка сайтов)?"; then
        ext_install
    else
        ui_msg "Готово. Перезапустите браузер."
    fi
}

# ======================= СВОБОДНЫЙ IP В ЗАЩИЩЁННОЙ СЕТИ =======================
CHECK_HOST="ecp.mis66.ru"    # чем проверяем, что адрес рабочий
SCAN_BATCH=30
SCAN_OUT=""

# Занят ли адрес: ответил ping или виден в ARP (хост без ICMP, но с MAC)
# ponytail: проверка по ICMP+ARP, не привилегированный ARP-скан; если в сети
# прячут хосты от обоих — заменить на arping/arp-scan.
ip_busy() {
    ping -c 1 -W 1 "$1" >/dev/null 2>&1 && return 0
    ip neigh show "$1" 2>/dev/null | grep -qE 'REACHABLE|STALE|DELAY|PROBE'
}

# Проверить свою /24 (адреса 1..254) и записать свободные в $SCAN_OUT
scan_free() {  # base(10.3.224)
    local base="$1" b i n
    for b in $(seq 0 8); do
        for i in $(seq 1 $SCAN_BATCH); do
            n=$(( b * SCAN_BATCH + i )); [ "$n" -le 254 ] || continue
            ( ip_busy "$base.$n" || echo "$base.$n" >> "$SCAN_OUT" ) &
        done
        wait
    done
}

do_freeip() {
    ui_yesno "Подобрать свободный IP в защищённой сети?\n\n1. Включу DHCP и узнаю адрес сети.\n2. Проверю все адреса этой сети.\n3. Пропишу свободный и проверю ping $CHECK_HOST." || { echo "Отменено."; return; }
    step "Ищу проводное подключение"; pick_conn || return 1
    save_original "$CON_UUID"

    step "Текущая сеть"
    read_current
    local local_addr="" local_gw="$CUR_GW" local_dns="$CUR_DNS" x
    for x in "${CUR_ADDRS[@]}"; do [[ "$x" == 10.* ]] || { local_addr="$x"; break; }; done
    [ -n "$local_addr" ] || local_addr="$(dev_addrs "$CON_DEV" | grep -v '^10\.' | grep -v '^169\.254\.' | head -1)"
    [ -n "$local_gw" ] || local_gw="$(dev_gw "$CON_DEV")"
    [[ "$local_gw" == 10.* ]] && local_gw=""
    if [ -n "$local_addr" ]; then ok "Локальная сеть: $local_addr ${local_gw:+, шлюз $local_gw}"
    else warn "Локальная сеть не найдена — будет только защищённая"; fi

    # --- адрес сети защищённой сети получаем по DHCP ---
    step "Получаю адрес сети по DHCP"
    DHCP_STARTED=1
    nmcli con mod "$CON_UUID" ipv4.method auto ipv4.addresses "" ipv4.gateway "" ipv4.routes "" \
        ipv4.dns "$(join_by , "${WORK_DNS[@]}")" ipv4.ignore-auto-dns yes || on_fail "nmcli не смог включить DHCP"
    nmcli --wait "$DHCP_WAIT" con up "$CON_UUID" >/dev/null 2>&1
    local t=0 dhcp_addr="" cand
    while [ $t -lt $DHCP_WAIT ]; do
        for cand in $(dev_addrs "$CON_DEV"); do
            [[ "${cand%/*}" == 169.254.* ]] && continue
            [ "${cand%/*}" = "${local_addr%/*}" ] && continue
            [ -n "$dhcp_addr" ] || dhcp_addr="$cand"      # хоть какой-то адрес от DHCP
            [[ "${cand%/*}" == 10.* ]] && { dhcp_addr="$cand"; break; }   # 10.x — приоритет
        done
        [ -n "$dhcp_addr" ] && break
        echo "  ...жду ответ DHCP"; sleep 3; t=$((t+3))
    done
    if [ -z "$dhcp_addr" ]; then
        warn "Адреса на $CON_DEV: $(dev_addrs "$CON_DEV" | tr '\n' ' ')"
        on_fail "защищённая сеть не выдала адрес за $DHCP_WAIT сек. — свободный IP не подобрать"
    fi

    local base="${dhcp_addr%/*}"; base="${base%.*}"; local pfx="${dhcp_addr#*/}" dhcp_gw
    dhcp_gw="$(dev_gw "$CON_DEV")"
    if [ -n "$dhcp_gw" ] && ! same_net "$dhcp_gw" "${dhcp_addr%/*}" "$pfx"; then dhcp_gw=""; fi
    if [ -z "$dhcp_gw" ]; then
        if same_net "$DEF_WORK_GW" "${dhcp_addr%/*}" "$pfx"; then
            dhcp_gw="$DEF_WORK_GW"; warn "DHCP не выдал шлюз — беру из настроек: $dhcp_gw"
        else
            warn "Шлюз защищённой сети не определился (DHCP выдал ${dhcp_addr})"
            dhcp_gw="$(ui_input "Шлюз защищённой сети:" "$DEF_WORK_GW")" || dhcp_gw=""
            is_v4 "$dhcp_gw" || on_fail "неверный шлюз защищённой сети: ${dhcp_gw:-пусто}"
        fi
    fi
    ok "Сеть: $base.0/$pfx, шлюз $dhcp_gw (DHCP выдал ${dhcp_addr})"
    [ "$pfx" -le 24 ] || warn "Маска /$pfx — проверяю только $base.1-$base.254"

    # --- ищем свободный адрес ---
    step "Проверяю адреса $base.1 - $base.254 (около 10 секунд)"
    SCAN_OUT="$(mktemp)"; scan_free "$base"
    local cand free=()
    while read -r cand; do
        [ -n "$cand" ] || continue
        [ "$cand" = "${dhcp_addr%/*}" ] && continue
        [ "$cand" = "$dhcp_gw" ] && continue
        [ "$cand" = "${local_addr%/*}" ] && continue
        same_net "$cand" "${dhcp_addr%/*}" "$pfx" || continue
        free+=("$cand")
    done < "$SCAN_OUT"
    rm -f "$SCAN_OUT"
    [ ${#free[@]} -gt 0 ] || on_fail "в сети $base.0/$pfx нет свободных адресов"
    local pick="${free[$(( RANDOM % ${#free[@]} ))]}"
    ok "Свободных адресов: ${#free[@]}, беру $pick"

    if ! ui_yesno "Свободный адрес: $pick\n\nПрописать его в защищённой сети?\nШлюз: $dhcp_gw\nЛокальная сеть: ${local_addr:-нет}"; then
        warn "Отменено — возвращаю настройки как были"
        load_original && apply_original "$CON_UUID" || warn "Верните вручную через «Вернуть всё назад»"
        echo "Отменено."; return
    fi

    step "Прописываю $pick"
    local alldns d; alldns="$(join_by , "${WORK_DNS[@]}" "${EXTRA_DNS[@]}")"
    IFS=',' read -r -a _ld <<< "$local_dns"
    for d in "${_ld[@]}"; do d="${d// /}"; [ -n "$d" ] && [[ ",$alldns," != *",$d,"* ]] && alldns="$alldns,$d"; done
    local routes="$ROUTE_NET $dhcp_gw"; [ -n "$CUR_ROUTES" ] && routes="$routes,$CUR_ROUTES"
    local addrs="$pick/$pfx" gw="$dhcp_gw"
    if [ -n "$local_addr" ]; then
        addrs="$local_addr,$pick/$pfx"
        [ -n "$local_gw" ] && gw="$local_gw"
    fi
    nmcli con mod "$CON_UUID" ipv4.method manual ipv4.addresses "$addrs" ipv4.gateway "$gw" \
        ipv4.dns "$alldns" ipv4.ignore-auto-dns yes ipv4.routes "$routes" \
        connection.permissions "" connection.autoconnect yes \
        || on_fail "nmcli не смог применить настройки"
    nmcli --wait 30 con up "$CON_UUID" >/dev/null 2>&1
    APPLIED=1
    ok "IP: $addrs"
    ok "Шлюз (интернет): $gw"
    ok "Маршрут: $ROUTE_NET -> $dhcp_gw"
    ok "DNS: $alldns"

    step "Проверка"
    if ping -c 3 -W 3 "$CHECK_HOST" >/dev/null 2>&1; then
        ok "$CHECK_HOST — отвечает"
        echo; echo "${G}ГОТОВО.${N}"
        ui_msg "Готово.\n\nСвободный IP: $pick\n$CHECK_HOST — отвечает."
    else
        warn "$CHECK_HOST — НЕ отвечает"
        getent hosts "$CHECK_HOST" >/dev/null 2>&1 || warn "Имя не разрешается — проверьте рабочие DNS ${WORK_DNS[0]} и ${WORK_DNS[1]}"
        ping -c 2 -W 2 "${WORK_DNS[0]}" >/dev/null 2>&1 || warn "Шлюз защищённой сети ${WORK_DNS[0]} не отвечает"
        ui_msg "IP $pick прописан, но $CHECK_HOST не отвечает.\n\nМаршрут и DNS прописаны. Если адрес заняли одновременно с вами — повторите «Подобрать свободный IP»."
    fi
}

# ======================= МЕНЮ =======================
M_SETUP="Настроить защищённую сеть"
M_FREEIP="Подобрать свободный IP в защищённой сети (DHCP)"
M_REVERT="Вернуть всё назад (убрать защищённую сеть)"
M_EXT="Поставить расширение $EXT_NAME в Chromium-GOST"
M_EXTDEL="Убрать расширение $EXT_NAME"
M_EXIT="Выход"
ch="$(ui_menu "Что сделать?" "$M_SETUP" "$M_FREEIP" "$M_REVERT" "$M_EXT" "$M_EXTDEL" "$M_EXIT")" || ch="$M_EXIT"
case "$ch" in
    "$M_SETUP")  do_setup ;;
    "$M_FREEIP") do_freeip ;;
    "$M_REVERT") do_revert ;;
    "$M_EXT")    ext_install ;;
    "$M_EXTDEL") ext_remove ;;
    *)           echo "Выход. Ничего не изменено." ;;
esac
if [ -n "$ASTRA_NET_IN_TERM" ] && [ "$UI" != text ]; then read -r -p "Enter — закрыть окно " _; fi
