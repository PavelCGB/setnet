#!/bin/bash
# =====================================================================
#  ASTRA UPDATE — правильные репозитории и обновление Astra Linux
#  SE 1.7.x / SE 1.8.x (включая «Орёл», «Воронеж», «Смоленск») и CE 2.12
#
#  Запуск:  bash astra-update.sh         — меню (под админом; или двойной щелчок)
#           bash astra-update.sh --now   — без вопросов: определить версию, прочитать какие
#                                          репозитории подключены, прописать их правильно
#                                          для своей версии, обновить и включить автообновление
#
#  Что делает:
#   - определяет точную версию (cat /etc/astra_version);
#   - выбирает самое быстрое официальное зеркало (dl / download.astralinux.ru);
#   - прописывает правильные репозитории (старые строки комментируются, есть бэкап);
#   - ускоряет apt (без переводов, без pdiff, повторы при обрывах);
#   - обновляет систему штатным astra-update;
#   - по желанию включает автообновление раз в неделю ночью.
# =====================================================================

MIRRORS=(https://dl.astralinux.ru https://download.astralinux.ru)
SRC="/etc/apt/sources.list"
FAST_CONF="/etc/apt/apt.conf.d/99astra-update-fast"
TIMER_NAME="astra-autoupdate"
LOG="/var/log/astra-autoupdate.log"
TAG="# [astra-update.sh]"

SELF="$(readlink -f "$0")"

# --- запуск двойным щелчком: открыть терминал ---
if [ ! -t 0 ] && [ -n "$DISPLAY" ] && [ -z "$ASTRA_UPD_IN_TERM" ] && [ "$1" != "--auto" ] && [ "$1" != "--now" ]; then
    export ASTRA_UPD_IN_TERM=1
    for t in fly-term x-terminal-emulator xterm; do
        command -v "$t" >/dev/null 2>&1 && exec "$t" -e bash "$SELF" "$@"
    done
fi
# --- права администратора ---
if [ "$(id -u)" -ne 0 ]; then
    echo "Нужны права администратора. Введите свой пароль:"
    exec sudo env DISPLAY="$DISPLAY" XAUTHORITY="${XAUTHORITY:-$HOME/.Xauthority}" ASTRA_UPD_IN_TERM=1 bash "$SELF" "$@"
fi

G=$'\e[32m'; Y=$'\e[33m'; R=$'\e[31m'; C=$'\e[36m'; N=$'\e[0m'
ok()   { echo "  ${G}[OK]${N} $*"; }
warn() { echo "  ${Y}[!]${N}  $*"; }
err()  { echo "  ${R}[X]${N}  $*"; }
step() { echo; echo "${C}== $*${N}"; }

# ======================= ОКНА =======================
if [ -n "$DISPLAY" ] && command -v zenity >/dev/null 2>&1; then UI=zenity
elif command -v whiptail >/dev/null 2>&1; then UI=whiptail
else UI=text; fi
TITLE="Обновление Astra Linux"
ui_msg() {
    set -- "$(printf '%b' "$1")"
    case $UI in
        zenity)   zenity --info --title "$TITLE" --text "$1" --width 460 2>/dev/null ;;
        whiptail) whiptail --title "$TITLE" --msgbox "$1" 18 76 ;;
        *)        echo; echo "$1"; read -r -p "Enter — продолжить " _ ;;
    esac
}
ui_yesno() {
    set -- "$(printf '%b' "$1")"
    case $UI in
        zenity)   zenity --question --title "$TITLE" --text "$1" --width 460 2>/dev/null ;;
        whiptail) whiptail --title "$TITLE" --yesno "$1" 16 76 ;;
        *)        local a; read -r -p "$1 [д/н] " a; [[ "$a" =~ ^[dDдДyY] ]] ;;
    esac
}
ui_menu() {
    local text; text="$(printf '%b' "$1")"; shift
    case $UI in
        zenity)
            zenity --list --title "$TITLE" --text "$text" --column "Действие" "$@" \
                --width 560 --height 420 --hide-header 2>/dev/null | head -1 ;;
        whiptail)
            local args=() i=1 it
            for it in "$@"; do args+=("$i" "$it"); i=$((i+1)); done
            local n; n=$(whiptail --title "$TITLE" --menu "$text" 22 80 9 "${args[@]}" 3>&1 1>&2 2>&3) || return 1
            local all=("$@"); echo "${all[$((n-1))]}" ;;
        *)
            echo >&2; echo "$text" >&2; local i=1 it
            for it in "$@"; do echo "  $i) $it" >&2; i=$((i+1)); done
            local n; read -r -p "Номер: " n
            local all=("$@"); [[ "$n" =~ ^[0-9]+$ ]] && [ "$n" -ge 1 ] && [ "$n" -le $# ] && echo "${all[$((n-1))]}" ;;
    esac
}

# ======================= СЕТЬ =======================
url_ok() {  # есть ли файл по ссылке
    if command -v curl >/dev/null 2>&1; then curl -fsSL -o /dev/null --max-time 15 -r 0-0 "$1" 2>/dev/null
    else wget -q --spider --timeout=15 "$1" 2>/dev/null; fi
}
url_time() {  # время скачивания (мс), 99999 если недоступно
    local t
    if command -v curl >/dev/null 2>&1; then
        t=$(curl -fsSL -o /dev/null --max-time 15 -w '%{time_total}' "$1" 2>/dev/null) || { echo 99999; return; }
        awk -v t="$t" 'BEGIN{printf "%d", t*1000}'
    else
        local s e; s=$(date +%s%N); wget -q -O /dev/null --timeout=15 "$1" 2>/dev/null || { echo 99999; return; }
        e=$(date +%s%N); echo $(( (e - s) / 1000000 ))
    fi
}
repo_ok() { url_ok "$1/dists/$2/InRelease" || url_ok "$1/dists/$2/Release"; }   # url codename

# ======================= ВЕРСИЯ =======================
detect_version() {
    RAW_VER="$(cat /etc/astra_version 2>/dev/null | head -1)"
    ARCH="$(dpkg --print-architecture 2>/dev/null)"
    local v; v="$(echo "$RAW_VER" | grep -oE '[0-9]+\.[0-9]+(\.[0-9]+)*' | head -1)"
    [ -z "$v" ] && v="$(. /etc/os-release 2>/dev/null; echo "$VERSION_ID" | grep -oE '[0-9]+\.[0-9]+')"
    MAJOR="$(echo "$v" | cut -d. -f1-2)"            # 1.7 / 1.8 / 2.12
    UPDATE="$(echo "$v" | cut -d. -f1-3)"           # 1.7.5 / 1.8.1
    [ "$UPDATE" = "$MAJOR" ] && UPDATE=""
    case "$MAJOR" in
        1.7) FAMILY="se17"; CODENAME="1.7_x86-64"; PRETTY="Astra Linux SE 1.7${UPDATE:+ (обновление $UPDATE)}" ;;
        1.8) FAMILY="se18"; CODENAME="1.8_x86-64"; PRETTY="Astra Linux SE 1.8${UPDATE:+ (обновление $UPDATE)}" ;;
        2.12) FAMILY="ce212"; CODENAME="orel"; PRETTY="Astra Linux CE 2.12 «Орёл» ($v)" ;;
        1.6) FAMILY="se16"; PRETTY="Astra Linux SE 1.6 ($v)" ;;
        *)   FAMILY="unknown"; PRETTY="неизвестная версия: ${RAW_VER:-нет /etc/astra_version}" ;;
    esac
    if [ "$ARCH" != "amd64" ] && [ "$FAMILY" != unknown ]; then FAMILY="arch"; fi
}

pick_mirror() {
    step "Выбираю самое быстрое официальное зеркало"
    local probe best="" bt=99999 m t
    case $FAMILY in
        se17)  probe="astra/stable/1.7_x86-64/repository-main/dists/1.7_x86-64/InRelease" ;;
        se18)  probe="astra/stable/1.8_x86-64/main-repository/dists/1.8_x86-64/InRelease" ;;
        ce212) probe="astra/stable/2.12_x86-64/repository/dists/orel/InRelease" ;;
    esac
    for m in "${MIRRORS[@]}"; do
        t=$(url_time "$m/$probe")
        if [ "$t" -ge 99999 ]; then warn "$m — недоступно"; else ok "$m — ${t} мс"; fi
        if [ "$t" -lt "$bt" ]; then bt=$t; best=$m; fi
    done
    [ -n "$best" ] && [ "$bt" -lt 99999 ] || { err "Ни одно зеркало Astra не отвечает. Проверьте интернет."; return 1; }
    MIRROR="$best"; ok "Выбрано: $MIRROR"
}

# Прочитать, какие репозитории Astra уже подключены (включая отключённые этой программой)
detect_wanted() {
    WANT_EXT=0; WANT_DEV=0
    local all
    all="$(cat "$SRC" /etc/apt/sources.list.d/*.list 2>/dev/null | grep -E "^[[:space:]]*(deb|$(printf '%s' "$TAG" | sed 's/[][]/\\&/g') deb)[[:space:]]" | grep -i astralinux)"
    echo "$all" | grep -qiE 'repository-extended|extended-repository' && WANT_EXT=1
    echo "$all" | grep -qiE 'repository-devel|devel-repository' && WANT_DEV=1
    local list="main"; [ "$FAMILY" = se17 ] && list="main, update, base"
    [ $WANT_EXT = 1 ] && list="$list, extended"; [ $WANT_DEV = 1 ] && list="$list, devel"
    ok "Сейчас подключены: $list — оставляю этот же набор"
}

# Составить строки репозиториев. $1 = frozen|stable, $2 = 1 если нужен extended
build_lines() {
    local mode="$1" ext="$2" dev="${3:-0}" base
    REPO_LINES=(); OPT_LINES=()
    case $FAMILY in
        se17)
            if [ "$mode" = frozen ]; then base="$MIRROR/astra/frozen/1.7_x86-64/$UPDATE"; else base="$MIRROR/astra/stable/1.7_x86-64"; fi
            REPO_LINES+=("deb $base/repository-main/     1.7_x86-64 main contrib non-free")
            REPO_LINES+=("deb $base/repository-update/   1.7_x86-64 main contrib non-free")
            REPO_LINES+=("deb $base/repository-base/     1.7_x86-64 main contrib non-free")
            [ "$ext" = 1 ] && REPO_LINES+=("deb $base/repository-extended/ 1.7_x86-64 main contrib non-free")
            ;;
        se18)
            if [ "$mode" = frozen ]; then base="$MIRROR/astra/frozen/1.8_x86-64/$UPDATE"; else base="$MIRROR/astra/stable/1.8_x86-64"; fi
            REPO_LINES+=("deb $base/main-repository/     1.8_x86-64 main contrib non-free non-free-firmware")
            [ "$ext" = 1 ] && REPO_LINES+=("deb $base/extended-repository/ 1.8_x86-64 main contrib non-free non-free-firmware")
            if [ "$dev" = 1 ]; then
                OPT_LINES+=("deb $base/devel-repository/ 1.8_x86-64 main contrib non-free non-free-firmware|deb $base/repository-devel/ 1.8_x86-64 main contrib non-free non-free-firmware")
            fi
            ;;
        ce212)
            REPO_LINES+=("deb $MIRROR/astra/stable/2.12_x86-64/repository/ orel main contrib non-free")
            ;;
    esac
}

# Проверить, что все репозитории существуют
check_lines() {
    local l u c bad=0
    for l in "${REPO_LINES[@]}"; do
        u="$(echo "$l" | awk '{print $2}')"; c="$(echo "$l" | awk '{print $3}')"
        if repo_ok "${u%/}" "$c"; then ok "есть: ${u#"$MIRROR"}"; else warn "нет: ${u#"$MIRROR"}"; bad=1; fi
    done
    # необязательные (devel): берём первый существующий вариант, иначе пропускаем
    local o alt found
    for o in "${OPT_LINES[@]}"; do
        found=""
        IFS='|' read -r -a _alts <<< "$o"
        for alt in "${_alts[@]}"; do
            u="$(echo "$alt" | awk '{print $2}')"; c="$(echo "$alt" | awk '{print $3}')"
            if repo_ok "${u%/}" "$c"; then found="$alt"; break; fi
        done
        if [ -n "$found" ]; then REPO_LINES+=("$found"); ok "есть: $(echo "$found" | awk '{print $2}' | sed "s#^$MIRROR##")"
        else warn "devel-репозитория для этой версии нет — пропускаю"; fi
    done
    return $bad
}

# Записать sources.list: старое — в бэкап и закомментировать
write_sources() {
    local bk="$SRC.bak-$(date +%F-%H%M%S)"
    cp -p "$SRC" "$bk" 2>/dev/null && ok "Бэкап: $bk"
    local tmp; tmp=$(mktemp)
    {
        echo "# astra-update.sh $(date '+%F %T') Astra $MAJOR $UPDATE"
        printf '%s\n' "${REPO_LINES[@]}" | tr -s ' '
        echo "# old lines (disabled):"
        if [ -f "$SRC" ]; then
            grep -v '^# === .* astra-update.sh' "$SRC" | grep -v '^# --- ' | grep -v '^# astra-update.sh ' | grep -v '^# old lines' | while IFS= read -r l; do
                if [[ "$l" =~ ^[[:space:]]*deb ]]; then echo "$TAG $l"
                elif [[ "$l" =~ ^[[:space:]]*$ ]]; then :
                else
                    # строки, которые мы сами писали раньше, не дублируем
                    printf '%s\n' "${REPO_LINES[@]}" | grep -qxF "$l" || echo "$l"
                fi
            done
        fi
    } > "$tmp"
    if ! cat "$tmp" > "$SRC" 2>/dev/null; then
        rm -f "$tmp"
        err "Не удалось записать $SRC."
        warn "На Astra SE выйдите из системы и войдите снова, выбрав уровень целостности 63 (высокий)."
        return 1
    fi
    rm -f "$tmp"
    # проверка: apt должен читать файл без ошибок, иначе — откат
    local chk; chk="$(apt-get update --print-uris -qq 2>&1 | grep -E '^(E|Е):' | head -3)"
    if [ -n "$chk" ]; then
        err "apt не принимает новый файл репозиториев:"
        echo "$chk" | sed 's/^/      /'
        echo "      Первые строки файла:"; head -4 "$SRC" | cat -A | sed 's/^/      /'
        [ -f "$bk" ] && cp -p "$bk" "$SRC" && warn "Вернул старый файл из бэкапа $bk — система не тронута"
        return 1
    fi
    # cdrom-строки в sources.list.d тоже мешают
    local f
    for f in /etc/apt/sources.list.d/*.list; do
        [ -f "$f" ] || continue
        grep -qE '^[[:space:]]*deb[[:space:]]+cdrom:' "$f" && sed -i -E "s|^([[:space:]]*deb[[:space:]]+cdrom:)|$TAG \1|" "$f" && warn "отключён cdrom в $f"
    done
    ok "Репозитории записаны в $SRC"
}

speed_up_apt() {
    cat > "$FAST_CONF" <<'EOF'
// Ускорение apt (astra-update.sh)
Acquire::Languages "none";          // не качать переводы описаний
Acquire::PDiffs "false";            // не собирать списки из кучи мелких diff-ов
Acquire::Retries "5";               // повторять при обрывах
Acquire::http::Timeout "30";
Acquire::https::Timeout "30";
Acquire::http::Pipeline-Depth "5";
APT::Get::Show-Versions "true";
EOF
    ok "Ускорение apt: $FAST_CONF"
}

run_update() {
    step "Обновляю списки пакетов"
    if ! apt-get update; then err "apt update завершился с ошибкой — смотрите сообщения выше"; return 1; fi
    ok "Списки пакетов обновлены"
    step "Устанавливаю обновления"
    if command -v astra-update >/dev/null 2>&1; then
        astra-update -A -r -T || { err "astra-update завершился с ошибкой"; return 1; }
    else
        warn "astra-update не найден — обновляю через apt"
        DEBIAN_FRONTEND=noninteractive apt-get -y -o Dpkg::Options::=--force-confold dist-upgrade || return 1
    fi
    apt-get -y autoremove >/dev/null 2>&1
    apt-get clean >/dev/null 2>&1
    ok "Обновление установлено"
    detect_version
    ok "Версия сейчас: $PRETTY"
    if [ -n "$NOASK" ]; then
        echo; echo "${G}ГОТОВО.${N} Перезагрузите компьютер, когда будет удобно."
        return 0
    fi
    if ui_yesno "Обновление установлено.\nВерсия: $PRETTY\n\nДля применения (особенно нового ядра) нужна перезагрузка.\nПерезагрузить сейчас?"; then
        reboot
    fi
}

# ======================= АВТООБНОВЛЕНИЕ =======================
autoupdate_on() {
    install -m 755 "$SELF" /usr/local/sbin/astra-update.sh
    cat > /etc/systemd/system/$TIMER_NAME.service <<EOF
[Unit]
Description=Автообновление Astra Linux (astra-update.sh)
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/astra-update.sh --auto
Nice=10
IOSchedulingClass=idle
EOF
    cat > /etc/systemd/system/$TIMER_NAME.timer <<EOF
[Unit]
Description=Автообновление Astra Linux раз в неделю

[Timer]
OnCalendar=Sun *-*-* 03:17
RandomizedDelaySec=45min
Persistent=true

[Install]
WantedBy=timers.target
EOF
    systemctl daemon-reload && systemctl enable --now $TIMER_NAME.timer >/dev/null 2>&1
    if systemctl is-active --quiet $TIMER_NAME.timer; then
        ok "Автообновление включено: каждое воскресенье около 03:17 (если ПК был выключен — при следующем включении)"
        ok "Журнал: $LOG"
        [ -z "$NOASK" ] && ui_msg "Автообновление включено.\n\nКаждое воскресенье ночью (или при первом включении после пропуска).\nПерезагрузка автоматически НЕ делается.\nЖурнал: $LOG"
    else
        err "Не удалось включить таймер systemd"
    fi
}
autoupdate_off() {
    systemctl disable --now $TIMER_NAME.timer >/dev/null 2>&1
    rm -f /etc/systemd/system/$TIMER_NAME.timer /etc/systemd/system/$TIMER_NAME.service
    systemctl daemon-reload
    ok "Автообновление выключено"
    ui_msg "Автообновление выключено."
}
autoupdate_status() {
    if systemctl is-enabled --quiet $TIMER_NAME.timer 2>/dev/null; then
        echo "включено (след. запуск: $(systemctl show $TIMER_NAME.timer -p NextElapseUSecRealtime --value 2>/dev/null))"
    else echo "выключено"; fi
}

# Тихий режим для таймера: репозитории не трогает, только обновляет
auto_mode() {
    exec >> "$LOG" 2>&1
    echo "===== $(date '+%F %T') автообновление ====="
    detect_version; echo "Версия: $PRETTY"
    apt-get update || { echo "apt update: ошибка"; exit 1; }
    if command -v astra-update >/dev/null 2>&1; then
        DEBIAN_FRONTEND=noninteractive astra-update -A -r -T < /dev/null
    else
        DEBIAN_FRONTEND=noninteractive apt-get -y -o Dpkg::Options::=--force-confold dist-upgrade
    fi
    apt-get -y autoremove; apt-get clean
    detect_version; echo "Готово. Версия: $PRETTY"
    [ -f /var/run/reboot-required ] && echo "Требуется перезагрузка"
    exit 0
}
[ "$1" = "--auto" ] && auto_mode

# ======================= СЦЕНАРИИ =======================
setup_repos() {  # $1 = frozen|stable
    local mode="$1" ext=0 dev=0
    pick_mirror || return 1
    step "Читаю текущие репозитории"
    detect_wanted
    if [ -n "$NOASK" ]; then ext=$WANT_EXT; dev=$WANT_DEV
    elif [ "$FAMILY" != ce212 ] && ui_yesno "Подключить расширенный репозиторий (extended)?\n\nВ нём дополнительные программы (Яндекс.Браузер, средства разработки и т.п.).\nОни не сертифицированы. Для обычной работы НЕ нужен.\n(Сейчас на компьютере: $([ $WANT_EXT = 1 ] && echo подключён || echo не подключён))\n\nПодключить?"; then ext=1; dev=$WANT_DEV; fi
    if [ "$mode" = frozen ] && [ -z "$UPDATE" ]; then warn "Номер обновления не определён — беру актуальную ветку"; mode=stable; fi
    step "Проверяю репозитории"
    build_lines "$mode" "$ext" "$dev"
    if ! check_lines; then
        if [ "$mode" = frozen ]; then
            warn "Для $UPDATE нет «замороженных» репозиториев — беру актуальную ветку $MAJOR"
            mode=stable; build_lines "$mode" "$ext" "$dev"; check_lines || { err "Репозитории недоступны"; return 1; }
        else err "Репозитории недоступны"; return 1; fi
    fi
    step "Записываю репозитории"
    write_sources || return 1
    speed_up_apt
    REPO_MODE="$mode"
}

do_update_frozen() { setup_repos frozen && run_update; }
do_update_latest() {
    ui_yesno "Будет установлено последнее оперативное обновление $MAJOR.\nНапример, 1.7.5 → последняя 1.7.x, 1.8.1 → последняя 1.8.x.\n\nЭто штатный путь Astra, но обновление большое (может занять 20–60 минут).\nПродолжить?" || return
    setup_repos stable && run_update
}
do_repos_only() {
    local P1="Репозитории своей версии ($UPDATE) — безопасно" P2="Актуальные репозитории $MAJOR (последнее обновление)"
    local ch; ch="$(ui_menu "Какие репозитории прописать?" "$P1" "$P2")" || return
    case "$ch" in "$P1") setup_repos frozen ;; "$P2") setup_repos stable ;; *) return ;; esac || return
    step "Проверяю apt update"
    apt-get update && ok "Готово" && ui_msg "Репозитории прописаны, apt update прошёл без ошибок."
}
do_restore() {
    local last; last="$(ls -1t "$SRC".bak-* 2>/dev/null | head -1)"
    [ -z "$last" ] && { ui_msg "Бэкапов sources.list нет."; return; }
    ui_yesno "Вернуть sources.list из бэкапа\n$last ?" || return
    cp -p "$last" "$SRC" && ok "Восстановлено из $last"
    rm -f "$FAST_CONF"
    apt-get update
    ui_msg "sources.list возвращён из бэкапа."
}

# ======================= МЕНЮ =======================
detect_version
echo "${C}Система:${N} $PRETTY   (файл /etc/astra_version: ${RAW_VER:-нет})"
case $FAMILY in
    se16)    ui_msg "Astra Linux SE 1.6 не поддерживает обновление из интернет-репозиториев.\nОбновления для 1.6 ставятся с дисков/образов из личного кабинета Astra."; exit 0 ;;
    arch)    ui_msg "Эта программа рассчитана на компьютеры x86-64 (amd64).\nУ вас: $ARCH. Репозитории для ARM/Эльбрус другие."; exit 0 ;;
    unknown) ui_msg "Не удалось определить версию Astra Linux.\n$PRETTY"; exit 1 ;;
esac

# --- режим одной командой: bash astra-update.sh --now ---
if [ "$1" = "--now" ]; then
    NOASK=1; UI=text
    echo "Режим без вопросов: репозитории своей версии + обновление"
    if [ "$FAMILY" = ce212 ]; then setup_repos stable && run_update; else do_update_frozen; fi
    rc=$?
    if [ $rc -eq 0 ]; then
        step "Включаю автообновление"
        if systemctl is-enabled --quiet $TIMER_NAME.timer 2>/dev/null; then ok "Уже включено"; else autoupdate_on; fi
        echo; echo "${G}ГОТОВО.${N} Система обновлена, дальше будет обновляться сама раз в неделю."
        echo "Перезагрузите компьютер, когда будет удобно."
    fi
    exit $rc
fi

M1="Обновить в пределах своей версии ($UPDATE) — безопасно"
M2="Обновить до последнего оперативного обновления $MAJOR"
M3="Только прописать правильные репозитории (без обновления)"
M4="Включить автообновление (раз в неделю ночью)"
M5="Выключить автообновление"
M6="Вернуть старый sources.list из бэкапа"
M7="Выход"
if [ "$FAMILY" = ce212 ]; then M1="Обновить систему (CE 2.12)"; M2=""; fi
items=("$M1"); [ -n "$M2" ] && items+=("$M2"); items+=("$M3" "$M4" "$M5" "$M6" "$M7")
ch="$(ui_menu "Система: $PRETTY\nАвтообновление: $(autoupdate_status)\n\nЧто сделать?" "${items[@]}")" || ch="$M7"
case "$ch" in
    "$M1") if [ "$FAMILY" = ce212 ]; then setup_repos stable && run_update; else do_update_frozen; fi ;;
    "$M2") do_update_latest ;;
    "$M3") if [ "$FAMILY" = ce212 ]; then setup_repos stable && apt-get update; else do_repos_only; fi ;;
    "$M4") autoupdate_on ;;
    "$M5") autoupdate_off ;;
    "$M6") do_restore ;;
    *) echo "Выход." ;;
esac
if [ -n "$ASTRA_UPD_IN_TERM" ]; then read -r -p "Enter — закрыть окно " _; fi
